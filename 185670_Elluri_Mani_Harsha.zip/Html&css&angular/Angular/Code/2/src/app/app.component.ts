import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'TwoWayBinding';
  name:string="";
  id:number;
  salary:number;
  department:string="";
  myClickFunction(event) { 
   
    alert(this.id +" " + this.name +" "+ this.salary +" "+this.department);
    console.log(event);
 }
}
