class basicPhone extends mobile{
    mobileType:string;
    constructor(id:number,name:string,cost:number,type:string)
    {
        super(id,name,cost);
        this.mobileType=type;
    }
    printMobileDetail()
    {
       this.arr.push(this.mobileId);
       this.arr.push(this.mobileName);
       this.arr.push(this.mobileCost);
       this.arr.push(this.mobileType);
       console.log(this.arr);
    }
}