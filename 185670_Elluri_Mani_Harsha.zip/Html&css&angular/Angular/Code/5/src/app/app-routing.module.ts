import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WelcomeComponent } from './welcome/welcome.component';
import { BooksComponent } from './books/books.component';

const routes: Routes = 
[
  {
    path:'welcome',
    component:WelcomeComponent
  },
  {
    path:'books',
    component:BooksComponent
  },
  {
    path:'', redirectTo:'Books',
    pathMatch:'full'
  }
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
