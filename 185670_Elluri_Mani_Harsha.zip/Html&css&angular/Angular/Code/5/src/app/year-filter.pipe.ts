import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'yearFilter'
})
export class YearFilterPipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    return value.filter((data)=>data.year.toString().indexOf(args)!==-1);
  }

}
