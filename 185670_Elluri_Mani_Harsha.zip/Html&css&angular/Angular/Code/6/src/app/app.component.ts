import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, CheckboxRequiredValidator } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular Form Validation Tutorial';
   angForm: FormGroup;
  id: number;
  name: string;
  cat: string;
  cost: number;
  avb: string;
   constructor(private fb: FormBuilder) {
    this.createForm();
  }
  myClickFunction(Id:number,Name:string,Cost:number,Cat:string,Avb:string){
    this.id=Id;
    this.name=Name;
    this.cost=Cost;
    this.cat=Cat;
    this.avb=Avb;
    alert(this.id +" " + this.name +" "+ this.cost +" "+this.cat+
    ""+this.avb);
  }
   createForm() {
    this.angForm = this.fb.group({
      id: ['', Validators.required ],
       name: ['', Validators.required ],
       cost: ['', Validators.required ],
       online: ['', Validators.required ],
       cat: ['', Validators.required ],
       avb: ['',  Validators.requiredTrue ]

    });
  }
}
